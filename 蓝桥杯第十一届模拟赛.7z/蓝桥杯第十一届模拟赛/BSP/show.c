#include "gpio.h"
#include "time.h"
#include "key.h"
#include "rtc.h"

extern uint8_t LCD_Flag;
extern uint8_t LCD1_Flag;

void Led_Comtrol(int led_num,int led_state)
{
	if(led_num>8 || led_num<1)
	return;//led��Ų��Ϸ�
	if(led_state==1)
	{
		HAL_GPIO_WritePin(GPIOD,GPIO_PIN_2,1);
		HAL_GPIO_WritePin(GPIOC,GPIO_PIN_All,1);
		HAL_GPIO_WritePin(GPIOC,GPIO_PIN_7<<led_num,0);
		HAL_GPIO_WritePin(GPIOD,GPIO_PIN_2,0);
	}
	else
	{
		HAL_GPIO_WritePin(GPIOD,GPIO_PIN_2,1);
		HAL_GPIO_WritePin(GPIOC,GPIO_PIN_All,1);
		HAL_GPIO_WritePin(GPIOC,GPIO_PIN_7<<led_num,1);
		HAL_GPIO_WritePin(GPIOD,GPIO_PIN_2,0);
	}	
}

void Main_Show(void)
{	
	Time_Get();	
}


void Setting_Show(void)
{
	Time_Setting();
} 

void Alarm_show(void)
{
	
	LCD_DisplayStringLine(Line4, (uint8_t *)"         nb           ");
	
}


void Lcd_Show(void)
{
	if(LCD_Flag==0)
	{
		Main_Show();
		
	}
	else if(LCD_Flag==1)
	{
		Time_Setting();
	}
//	else
//	{
//		Alarm_show();
//	}
	
	
	
	//HAL_RTC_DeInit(&hrtc);

	
}
