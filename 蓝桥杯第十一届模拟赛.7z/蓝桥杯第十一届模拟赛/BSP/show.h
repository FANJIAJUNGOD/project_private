#ifndef __SHOW_H_
#define __SHOW_H_

void Led_Comtrol(int led_num,int led_state);
void Lcd_Show(void);

#endif
