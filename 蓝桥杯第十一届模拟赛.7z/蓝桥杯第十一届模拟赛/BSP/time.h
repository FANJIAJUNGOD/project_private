#ifndef __TIME_H_
#define __TIME_H_

void Time_Get(void);
void Time_Setting(void);
#endif

