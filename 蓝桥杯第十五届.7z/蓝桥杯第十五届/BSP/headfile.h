#ifndef __HEADFILE_H__
#define __HEADFILE_H__

//#include "stm32g4xx.h"

#include "main.h"
#include "tim.h"
#include "gpio.h"

#include "key.h"
#include "show.h"

#include "stdio.h"
#include "lcd.h"
#include "fonts.h"

extern uint8_t LCD_Flag;


#endif 
