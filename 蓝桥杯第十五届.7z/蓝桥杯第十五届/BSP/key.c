
#include "gpio.h"
#include "show.h"

extern uint8_t LCD_Flag ;

//按键初始状态
int key1_state=0;
int key2_state=0;
int key3_state=0;
int key4_state=0;

int key1_last_state=0;
int key2_last_state=0;
int key3_last_state=0;
int key4_last_state=0;

uint8_t show_flag=0;
uint8_t Para_flag=0;
extern uint16_t PD;
extern uint16_t PH;
extern int16_t PX;


//按键扫描
void Key_Scan(void)
{
	//读取四个按键管脚电频，为低则视为被按下
	key1_state=HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_0);
	key2_state=HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_1);
	key3_state=HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_2);
	key4_state=HAL_GPIO_ReadPin(GPIOA,GPIO_PIN_0);		
	
	if(key1_state==0&&key1_last_state==1)//松手检测
	{
		//按键一被按下 +
		if(Para_flag==0)
		{
			PD+=100;
			if(PD>=1000)
			{
				PD=1000;
			}
			if(PD<=100)
			{
				PD=100;
			}		
		}
		else if (Para_flag==1)
		{
			PH+=100;
			if(PH>=10000)
			{
				PH=10000;
			}
			if(PH<=1000)
			{
				PH=1000;
			}
		}
		else
		{
			PX+=100;
			if(PX>=1000)
			{
				PX=1000;
			}
			if(PX<=-1000)
			{
				PX=-1000;
			}
		}
				
	}
	if(key2_state==0&&key2_last_state==1)
	{
		//按键二被按下 -
			if(Para_flag==0)
		{
			PD-=100;
			if(PD>=1000)
			{
				PD=1000;
			}
			if(PD<=100)
			{
				PD=100;
			}		
		}
		else if (Para_flag==1)
		{
			PH-=100;
			if(PH>=10000)
			{
				PH=10000;
			}
			if(PH<=1000)
			{
				PH=1000;
			}
		}
		else
		{
			PX-=100;
			if(PX>=1000)
			{
				PX=1000;
			}
			if(PX<=-1000)
			{
				PX=-1000;
			}
		}
			
		
	}
	if(key3_state==0&&key3_last_state==1)
	{
		//按键三被按下
		if(LCD_Flag==0)//在数据界面
		{
			show_flag++;
			if(show_flag==2)
			{
				show_flag=0;
			}
		}
		if(LCD_Flag==1)//在参数界面
		{
			Para_flag++;
			if(Para_flag==3)
			{
				Para_flag=0;
			}
		}
		
	}
	if(key4_state==0&&key4_last_state==1)//切换界面
	{
		//按键四被按下
		LCD_Flag++;
		LCD_Flag %= 3;
		
		
	}
	
	key1_last_state=key1_state;
	key2_last_state=key2_state;
	key3_last_state=key3_state;
	key4_last_state=key4_state;
	
	
}