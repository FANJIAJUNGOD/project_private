#ifndef __LED_H_
#define __LED_H_

#include "main.h"

void LED_Control(int led_num ,int led_state);



#endif
