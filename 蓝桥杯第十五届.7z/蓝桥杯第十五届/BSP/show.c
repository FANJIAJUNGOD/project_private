
#include "main.h"
#include "stdio.h"
#include "gpio.h"
#include "tim.h"
#include "led.h"
#include "key.h"
#include <stdbool.h> 
//#include "lcd.h"

double fre, capture,fre1, capture1;

extern uint8_t show_flag;//切记定义标志位是一定要使用uint8_t==unsigned char

char buf[32]={0};//定义一个数组
float A=0;//A通道频率
float B=0;//B通道频率
float Cycle_A = 0;//A通道周期
float Cycle_B = 0;//B通道周期
uint16_t PD=1000;
uint16_t PH=5000;
int16_t PX=0;
uint8_t NDA=0;
uint8_t NDB=0;
uint8_t NHA=0;
uint8_t NHB=0;
uint8_t LCD_Flag=0 ;

int NDA_time=0;
int NDB_time=0;
int NHA_time=0;
int NHB_time=0;

uint8_t NHA_flag=0;
uint8_t Sudden_Change_Flag=0;


uint32_t fre_max=5000;
uint32_t fre1_max=5000;
uint32_t fre_min=100;
uint32_t fre1_min=100;

bool last_state_A = false; // 通道 A 上次是否超限
bool last_state_B = false; // 通道 B 上次是否超限 

void Time_Count(void);
//void Sudden_Change_Time(void);

void DATA_Show(void)
{
	
	LCD_DisplayStringLine(Line1, (uint8_t *)"        DATA         ");
//	sprintf(buf,"       A=%dHz           ",fre);
//	LCD_DisplayStringLine(Line3, (uint8_t *)buf);
	
	if(fre+PX>0)
	{
			if(fre/1000 >= 1)//超过1000hz，则转为khz
		{			
			sprintf(buf,"       A=%.2lfKHz           ",(fre+PX)/1000);
			LCD_DisplayStringLine(Line3, (uint8_t *)buf);
		}
		else
		{
			sprintf(buf,"       A=%.fHz           ",fre+PX);
			LCD_DisplayStringLine(Line3, (uint8_t *)buf);
		}
		
		if(fre1/1000 >= 1)//超过1000hz，则转为khz
		{
			sprintf(buf,"       B=%.2lfKHz           ",(fre1+PX)/1000);
			LCD_DisplayStringLine(Line4, (uint8_t *)buf);
		}
		else
		{
			sprintf(buf,"       B=%.fHz           ",fre1+PX);
			LCD_DisplayStringLine(Line4, (uint8_t *)buf);
		}
	}	
	else
	{
		LCD_DisplayStringLine(Line3, (uint8_t *)"       A=NULL           ");
		LCD_DisplayStringLine(Line4, (uint8_t *)"       B=NULL           ");
	}
	
	LCD_DisplayStringLine(Line5, (uint8_t *)"                    ");
	LCD_DisplayStringLine(Line6, (uint8_t *)"                    ");
}

void Cycle_Show(void)
{
	LCD_DisplayStringLine(Line1, (uint8_t *)"        DATA        ");
	Cycle_A=1000000*(1/(fre+PX));
	Cycle_B=1000000*(1/(fre1+PX));
	if(fre+PX>0)
	{
			if(Cycle_A >= 1000)
		{
			sprintf(buf,"       A=%.2fmS           ",Cycle_A/1000);
			LCD_DisplayStringLine(Line3, (uint8_t *)buf);
		}
		else
		{
			sprintf(buf,"       A=%.fuS           ",Cycle_A);
			LCD_DisplayStringLine(Line3, (uint8_t *)buf);
		}
		if(Cycle_B >= 1000)
		{
			sprintf(buf,"       B=%.2fmS           ",Cycle_B/1000);
			LCD_DisplayStringLine(Line4, (uint8_t *)buf);
		}
		else
		{
			sprintf(buf,"       B=%.fuS           ",Cycle_B);
			LCD_DisplayStringLine(Line4, (uint8_t *)buf);
		}
	}
	else
	{
		LCD_DisplayStringLine(Line3, (uint8_t *)"       A=NULL           ");
		LCD_DisplayStringLine(Line4, (uint8_t *)"       B=NULL           ");
	}
	
	LCD_DisplayStringLine(Line5, (uint8_t *)"                    ");
	LCD_DisplayStringLine(Line6, (uint8_t *)"                    ");
}

void Para_Show(void)
{
	LCD_DisplayStringLine(Line1, (uint8_t *)"        PARA        ");
	sprintf(buf,"       PD=%dHz           ",PD);
	LCD_DisplayStringLine(Line3, (uint8_t *)buf);
	sprintf(buf,"       PH=%dHz           ",PH);
	LCD_DisplayStringLine(Line4, (uint8_t *)buf);
	sprintf(buf,"       PX=%dHz           ",PX);
	LCD_DisplayStringLine(Line5, (uint8_t *)buf);
	LCD_DisplayStringLine(Line6, (uint8_t *)"                    ");
}

void Recd_Show(void)
{
	LCD_DisplayStringLine(Line1, (uint8_t *)"        RECD        ");
	
		Sudden_Change_Flag=1;
	if(Sudden_Change_Flag==0)
	{
		sprintf(buf,"       NDA=%d           ",NDA);//频率突变次数
		LCD_DisplayStringLine(Line3, (uint8_t *)buf);
		sprintf(buf,"       NDB=%d           ",NDB);
		LCD_DisplayStringLine(Line4, (uint8_t *)buf);	
	}
	else
	{
		LCD_DisplayStringLine(Line4, (uint8_t *)"       NDA=             ");	
		LCD_DisplayStringLine(Line3, (uint8_t *)"       NDB=            ");
	}
	
	
	Time_Count();
	sprintf(buf,"       NHA=%d           ",NHA_time);//频率超限次数
	LCD_DisplayStringLine(Line5, (uint8_t *)buf);
	
	sprintf(buf,"       NHB=%d           ",NHB_time);
	LCD_DisplayStringLine(Line6, (uint8_t *)buf);
}



void LCD_Show(void)
{
	if(LCD_Flag==0)
	{
		LED_Control(1,1);
		if(show_flag==0)
		{
			DATA_Show();
		}
		else
		{
			Cycle_Show();
		}		
	}
	else if(LCD_Flag==1)
	{
		Para_Show();
		LED_Control(1,0);
	}
	else
	{
		Recd_Show();
	}
}


//频率回调函数
void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim)//定时器三通道一的频率测量
{
		//__HAL_TIM_SetCounter(htim,0);//计数清零，方便下一次计数//这个是最重要的，必须清零计数
    if(htim->Instance == TIM3)//判断是定时器三
    {
        capture = HAL_TIM_ReadCapturedValue(&htim3, TIM_CHANNEL_1) + 1;
        fre = 1000000 / capture;
				__HAL_TIM_SetCounter(&htim3,0);
    }
		if(htim->Instance == TIM2)//判断是定时器二
		{
				capture1 = HAL_TIM_ReadCapturedValue(&htim2, TIM_CHANNEL_1) + 1;
        fre1 = 1000000 / capture1;
				__HAL_TIM_SetCounter(&htim2,0);
		}
		
//	uint32_t  cc1_value = 0;
//	cc1_value = __HAL_TIM_GET_COUNTER(htim);
//	__HAL_TIM_SetCounter(htim,0);//计数清零，方便下一次计数
//	
//	if(htim == &htim2) //定时器2，对应的是PA15引脚，R40
//	{
//		capture = 1000000/cc1_value;
//	}
//	
//	if(htim == &htim3) //定时器3，对应的是PB4引脚，R39
//	{
//		capture1 = 1000000/cc1_value;
//	}

}



void Time_Count (void)
{
	// 处理通道 A
  bool cur_state_A = (fre+PX > PH);
	if (!last_state_A && cur_state_A) { // 上次未超限，现在超限
			NHA_time++;
	}
	last_state_A = cur_state_A;

	// 处理通道 B       
	bool cur_state_B = (fre1+PX > PH);
	if (!last_state_B && cur_state_B) { // 上次未超限，现在超限
			NHB_time++;
	}
	last_state_B = cur_state_B;
}

//void Sudden_Change_Time(void)
//{
//	
//	
//	
//}