#include "gpio.h"


//����led
void LED_Control(int led_num ,int led_state)
{
	if(led_num>8 || led_num<1)
		return;//��Ų��Ϸ�
	if(led_state==1)//����
	{		
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_2, 1);
		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_All, 1);
		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7 << led_num, 0);
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_2, 0);
	}
	else
	{
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_2, 1);
		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_All, 1);
		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7 << led_num, 1);
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_2, 0);
	}	
	
}