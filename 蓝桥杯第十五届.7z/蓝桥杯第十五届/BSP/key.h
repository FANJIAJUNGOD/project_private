#ifndef __KEY_H_
#define __KEY_H_

#include "main.h"


void Key_Scan(void);

#endif
