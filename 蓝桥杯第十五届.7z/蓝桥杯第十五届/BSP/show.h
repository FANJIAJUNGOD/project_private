#ifndef __SHOW_H_
#define __SHOW_H_

#include "main.h"

void LCD_Show(void);
void DATA_Show(void);
void Cycle_Show(void);
void Para_Show(void);
void Recd_Show(void);


#endif