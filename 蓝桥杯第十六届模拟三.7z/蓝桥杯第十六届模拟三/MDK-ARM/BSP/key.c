#include "main.h"

uint8_t key1_state=0;
uint8_t key2_state=0;
uint8_t key3_state=0;
uint8_t key4_state=0;

uint8_t key1_state_last=0;
uint8_t key2_state_last=0;
uint8_t key3_state_last=0;
uint8_t key4_state_last=0;

int page_value=0;
int Warn_Mode=0;//�л������ޱ���
int Set_Mode=0;//�����޸�״̬

extern uint8_t Con;


void Key_Scan(void)
{
	key1_state=HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_0);
	key2_state=HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_1);
	key3_state=HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_2);
	key4_state=HAL_GPIO_ReadPin(GPIOA,GPIO_PIN_0);
	if(key1_state==0 && key1_state_last==1)
	{
		page_value++;
		page_value%=3;
	}
	if(key2_state==0 && key2_state_last==1)
	{
		if(page_value==2)//�ڲ���������
		{
		Warn_Mode++;
		Warn_Mode%=2;
		}
	}
	if(key3_state==0 && key3_state_last==1)
	{
		if(page_value==2)//�ڲ���������
		{
			Set_Mode++;
			Set_Mode%=2;
		}
		
	}
	if(key4_state==0 && key4_state_last==1)
	{
		Con=0;//������������
	}
	
	
	key1_state_last=key1_state;
	key2_state_last=key2_state;
	key3_state_last=key3_state;
	key4_state_last=key4_state;
	
}
