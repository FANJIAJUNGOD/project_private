#ifndef __SHOW_H_
#define __SHOW_H_

void Page_Show(void);

#endif
