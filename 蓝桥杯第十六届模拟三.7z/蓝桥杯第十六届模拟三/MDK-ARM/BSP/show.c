#include "main.h"
#include "key.h"
#include "stdio.h"
#include "gpio.h"
#include "adc.h"
#include "tim.h"

char buf[32]={0};

extern int page_value;
extern int Warn_Mode;
extern int Set_Mode;


double Rate=0;//����
double Rate_Last=1;
uint8_t Con=0;//�ܱ�������
uint8_t Max=0;//�������
uint8_t Max_Last=1;
uint8_t Min=0;//��С����
uint8_t Min_Last=200;
float High=100;//���ޱ���
float Low=60;//���ޱ���
int flag=0;//������־λ
int Con_Mode=0;
int Con_Mode1=0;
double Capture,fre;

void Led_Control(uint8_t pin,uint8_t state);
uint16_t ADC_GetValue(void);


void Heart_Show(void)//���ݽ���
{
	LCD_DisplayStringLine(Line1, (uint8_t *)"       HEART              ");
	Rate=0.17*fre-140;	
	sprintf(buf,"      RATE:%.f               ",Rate);
	LCD_DisplayStringLine(Line3, (uint8_t *)buf);
	if(Rate>High  || Rate<Low)
	{
		if(flag==1)
		{
			Con++;
			flag=0;
			Con_Mode1=1;
		}
	}
	else
	{
		flag=1;
		Con_Mode1=0;
	}

	sprintf(buf,"       CON:%d               ",Con);
	LCD_DisplayStringLine(Line4, (uint8_t *)buf);
}



void Record_Show(void)//��¼����
{
	LCD_DisplayStringLine(Line1, (uint8_t *)"       RECORD            ");
	if(Rate>Max_Last)
	{
		Max_Last=Rate;//������������ֵ����Ԥ������ֵ�������ڵ����ֵ����Max_Last
	}	
	sprintf(buf,"       MAX:%d              ",Max_Last);
	if(Rate<Min_Last)
	{
		Min_Last=Rate;//�����������СֵС��Ԥ�����Сֵ�������ڵ���Сֵ��ֵ����Min_Last
	}
	LCD_DisplayStringLine(Line3, (uint8_t *)buf);
	sprintf(buf,"       MIN:%d              ",Min_Last);	
	LCD_DisplayStringLine(Line4, (uint8_t *)buf);
	
}

void Para_Show(void)//��������
{
	LCD_DisplayStringLine(Line1, (uint8_t *)"        PARA              ");
	sprintf(buf,"      High:%.f               ",High);	
	LCD_DisplayStringLine(Line3, (uint8_t *)buf);
	sprintf(buf,"       Low:%.f              ",Low);	
	LCD_DisplayStringLine(Line4, (uint8_t *)buf);
	if(Warn_Mode==0 && Set_Mode==1)
	{
		LCD_SetTextColor(Red);
		uint16_t ADC_Value=ADC_GetValue();
		float value=(ADC_Value*3.3)/4095;//����ȡ��adcֵת��Ϊ��ѹֵ
		High=15+45*value;
		if(High>150)
		{
			High=150;
		}
		if(High<60)
		{
			High=60;			
		}
		if(High<Low)
		{
			High=Low+1;
		}
		sprintf(buf,"      High:%.f               ",High);	
	  LCD_DisplayStringLine(Line3, (uint8_t *)buf);
		LCD_SetTextColor(Black);
	}
	else if(Warn_Mode==1 && Set_Mode==1)
	{
		uint16_t ADC_Value=ADC_GetValue();
		float value=(ADC_Value*3.3)/4095;//����ȡ��adcֵת��Ϊ��ѹֵ
		Low=15+45*value;
		if(Low>150)
		{
			Low=150;
		}
		if(Low<60)
		{
			Low=60;			
		}
		if(Low>High)
		{
			Low=High-1;
		}
		LCD_SetTextColor(Red);
		sprintf(buf,"       Low:%.f               ",Low);	
		LCD_DisplayStringLine(Line4, (uint8_t *)buf);
		LCD_SetTextColor(Black);
	}
	
	
}


void Page_Show(void)
{
	if(page_value==0)
	{		
		Heart_Show();//���ݽ���		
		if(Con_Mode1==1)
		{
			Con_Mode=1;
			Con_Mode1=0;
		}
		else if(Con_Mode1==0 && Con_Mode==0)
		{
			Led_Control(1,1);
		}
		
		
	}
	else if(page_value==1)
	{
		Record_Show();//��¼����
		Led_Control(2,1);
	}
	else if(page_value==2)
	{
		if(Warn_Mode==0 && Set_Mode==1)//���������޸�״̬��ѡ�����ޱ���
		{
			Led_Control(4,1);
		}
		else if (Warn_Mode==1 && Set_Mode==1)//���������޸�״̬��ѡ�����ޱ���
		{
			Led_Control(5,1);
		}
		else
		{
			Led_Control(3,1);
		}
		Para_Show();//��������
		
	}	
	
	//����
	sprintf(buf,"Set_Mode=%d",Set_Mode);	
	LCD_DisplayStringLine(Line7, (uint8_t *)buf);
	sprintf(buf,"Adc=%d",ADC_GetValue());	
	LCD_DisplayStringLine(Line8, (uint8_t *)buf);
	sprintf(buf,"Fre=%.2f",fre);	
	LCD_DisplayStringLine(Line9, (uint8_t *)buf);
}

void Led_Control(uint8_t pin,uint8_t state)
{
	if(pin>8 || pin<1) return;
	if(state==1)
	{
		HAL_GPIO_WritePin(GPIOD,GPIO_PIN_2,1);
		HAL_GPIO_WritePin(GPIOC,GPIO_PIN_All,1);
		HAL_GPIO_WritePin(GPIOC,GPIO_PIN_7<<pin,0);
		HAL_GPIO_WritePin(GPIOD,GPIO_PIN_2,0);
	}
	else if(state==0)
	{
		HAL_GPIO_WritePin(GPIOD,GPIO_PIN_2,1);
		HAL_GPIO_WritePin(GPIOC,GPIO_PIN_All,1);
		HAL_GPIO_WritePin(GPIOC,GPIO_PIN_7<<pin,1);
		HAL_GPIO_WritePin(GPIOD,GPIO_PIN_2,0);
	}
		
}

uint16_t ADC_GetValue(void)
{
	uint16_t ADC_Value=0;
	HAL_ADC_Start(&hadc2);
	ADC_Value=HAL_ADC_GetValue(&hadc2);
	//return ADC_Value;
}


void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim)
{
	if(htim->Instance==TIM3)
	{
		Capture=HAL_TIM_ReadCapturedValue(&htim3,TIM_CHANNEL_1);
		fre=1000000/Capture;
		__HAL_TIM_SetCounter(&htim3,0);	
		HAL_TIM_IC_Start(&htim3,TIM_CHANNEL_1);//�������벶��
		if(fre >2000)
		{
			fre=2000;
		}
		if(fre<1000)
		{
			fre=1000;
		}		
	}
	
	
}