#ifndef __SHOW_H_
#define __SHOW_H_

void Page_show(void);
uint16_t ADC_GetValue (void);
void Led_Control(uint8_t pin,uint8_t state);
#endif
