#include "main.h"
#include "show.h"
#include "i2c.h"

uint8_t key1_state = 0;
uint8_t key2_state = 0;
uint8_t key3_state = 0;
uint8_t key4_state = 0;

uint8_t key1_state_last = 0;
uint8_t key2_state_last = 0;
uint8_t key3_state_last = 0;
uint8_t key4_state_last = 0;

uint8_t Switch_place=0; 
uint8_t Switch1_place=0; 

int Page_value=0;

extern int init_Password1;
extern int init_Password2;
extern int init_Password3;

extern int Password1;
extern int Password2;
extern int Password3;

int setting_flag=0;

void Key_Scan(void)
{
	key1_state=HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_0);
	key2_state=HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_1);
	key3_state=HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_2);
	key4_state=HAL_GPIO_ReadPin(GPIOA,GPIO_PIN_0);
	
	if(key1_state==0 && key1_state_last==1)//ȷ�ϰ���������������һλ����
	{
		if(Page_value==0)
		{
		  Switch_place++;
		
		
		}
		if(Switch_place==3)
		{
		  if(Password1 ==init_Password1 && Password2 ==init_Password2 && Password3 ==init_Password3)//����ƥ��
		  {
			 
			Page_value=1;
			setting_flag=1;//˵����ʱ�Ѿ������޸�����ģʽ  
			  //Led_Control(1,0);
				
		  }
		  else//�������
		  {
			Page_value=0;  
		  }
			Switch_place=0;
		} 
		
		if(Page_value==1)
		{
			Switch1_place++;
			
		}
		if(Switch1_place==2)
		{
			setting_flag=0;
		}
		
		if(Switch1_place==5)
		{
			Page_value=0;
			Switch1_place=0;
			
		}
		
		
//		HAL_GPIO_WritePin(GPIOD,GPIO_PIN_2,1);
//		HAL_GPIO_WritePin(GPIOC,GPIO_PIN_All,1);
//		HAL_GPIO_WritePin(GPIOC,GPIO_PIN_8,0);
//		HAL_GPIO_WritePin(GPIOD,GPIO_PIN_2,0);
		
	}
	if(key2_state==0 && key2_state_last==1)
	{
		
	}
	if(key3_state==0 && key3_state_last==1)
	{
		
	}
	if(key4_state==0 && key4_state_last==1)
	{
		
	}
	
	key1_state_last=key1_state;
	key2_state_last=key2_state;
	key3_state_last=key3_state;
	key4_state_last=key4_state;
	
	
	
}