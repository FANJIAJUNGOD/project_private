#include "main.h"
#include "stdio.h"
#include "adc.h"
#include "key.h"
#include "i2c.h"

char buf[32]={0};

int init_Password1= 0;
int init_Password2= 1;
int init_Password3= 2;

int Password1= -1;
int Password2= -1;
int Password3= -1;

extern uint8_t Switch_place;
extern uint8_t Switch1_place;
extern int Page_value;
extern int setting_flag;

void Switch_password(void);
uint16_t ADC_GetValue (void);
void Led_Control(int pin,int state);

void Lock_show(void)

{
	uint16_t ADC_Value=ADC_GetValue();
	float value=(ADC_Value*3.3)/4095;//����ȡ��adcֵת��Ϊ��ѹֵ
	LCD_DisplayStringLine(Line1, (uint8_t *)"        Lock            ");
	LCD_DisplayStringLine(Line3, (uint8_t *)"      Pass Word         ");
//	if(Password1==-1 && Password1==-1 && Password1==-1)
//	{
//		LCD_DisplayStringLine(Line4, (uint8_t *)"        * * *       ");
//	}
//	else
//	{
		if(Switch_place==0)//����0 value<1.50
		{
			if(value<1.50)
			{
				Password1=0;
			}
			else if(value>=1.50 && value<=2.50)
			{
				Password1=1;
			}
			else
			{
				Password1=2;
			}		
			sprintf(buf,"        %d * *       ",Password1);
			LCD_DisplayStringLine(Line4, (uint8_t *)buf);
		}
		else if(Switch_place==1)//����0
		{
			if(value<1.50)
			{
				Password2=0;
			}
			else if(value>=1.50 && value<=2.50)
			{
				Password2=1;
			}
			else
			{
				Password2=2;
			}	
			sprintf(buf,"        %d %d *       ",Password1,Password2);
			LCD_DisplayStringLine(Line4, (uint8_t *)buf);
		}
		else//����2
		{
			if(value<1.50)
			{
				Password3=0;
			}
			else if(value>=1.50 && value<=2.50)
			{
				Password3=1;
			}
			else
			{
				Password3=2;
			}
			sprintf(buf,"        %d %d %d       ",Password1,Password2,Password3);
			LCD_DisplayStringLine(Line4, (uint8_t *)buf);
		}
	}
//}
void Set_show(void)
{
	uint16_t ADC_Value=ADC_GetValue();
	float value=(ADC_Value*3.3)/4095;//����ȡ��adcֵת��Ϊ��ѹֵ
	LCD_DisplayStringLine(Line1, (uint8_t *)"        Set            ");
	LCD_DisplayStringLine(Line3, (uint8_t *)"      Change         ");
		if(Switch1_place==1)
		{
			LCD_DisplayStringLine(Line4, (uint8_t *)"        * * *       ");
		}
	 else if(Switch1_place==2)//����0 value<1.50
		{
			if(value<1.50)
			{
				init_Password1=0;
			}
			else if(value>=1.50 && value<=2.50)
			{
				init_Password1=1;
			}
			else
			{
				init_Password1=2;
			}		
			sprintf(buf,"        %d * *       ",init_Password1);
			LCD_DisplayStringLine(Line4, (uint8_t *)buf);
		}
		else if(Switch1_place==3)//����0
		{
			if(value<1.50)
			{
				init_Password2=0;
			}
			else if(value>=1.50 && value<=2.50)
			{
				init_Password2=1;
			}
			else
			{
				init_Password2=2;
			}	
			sprintf(buf,"        %d %d *       ",init_Password1,init_Password2);
			LCD_DisplayStringLine(Line4, (uint8_t *)buf);
		}
		else if(Switch1_place==4)//����2
		{
			if(value<1.50)
			{
				init_Password3=0;
			}
			else if(value>=1.50 && value<=2.50)
			{
				init_Password3=1;
			}
			else
			{
				init_Password3=2;
			}
			sprintf(buf,"        %d %d %d       ",init_Password1,init_Password2,init_Password3);
			LCD_DisplayStringLine(Line4, (uint8_t *)buf);
		}
			eeprom_write(0,init_Password1);
			eeprom_write(1,init_Password2);
			eeprom_write(2,init_Password3);
}

void Page_show(void)
{
	//if(Password1 !=init_Password1 || Password2 !=init_Password2 || Password3 !=init_Password3 ||Switch_place!=3)
	if(Page_value==0)
	{
		Lock_show();
		Led_Control(1,1);		
	}
	else if(Page_value==1)
	{
		Set_show();
		Led_Control(2,1);
	}
}

uint16_t ADC_GetValue (void)
{
	uint16_t adc_value = 0;
	//double value=0;
	HAL_ADC_Start(&hadc2);
	adc_value=HAL_ADC_GetValue(&hadc2);
	//value = (adc_value/4096)*3.3;
	return adc_value;
}

//void Switch_password(void)
//{
//	uint16_t ADC_Value=ADC_GetValue();
//	float value=(ADC_Value*3.3)/4095;//����ȡ��adcֵת��Ϊ��ѹֵ
//	if(Switch_place==0)//����0 value<1.50
//	{
//		if(value<1.50)
//		{
//			Password1=0;
//		}
//		else if(value>=1.50 && value<=2.50)
//		{
//			Password1=1;
//		}
//		else
//		{
//			Password1=2;
//		}
//	}
//	else if(Switch_place==1)//����0
//	{
//		if(value<1.50)
//		{
//			Password2=0;
//		}
//		else if(value>=1.50 && value<=2.50)
//		{
//			Password2=1;
//		}
//		else
//		{
//			Password2=2;
//		}
//	}
//	else//����2
//	{
//		if(value<1.50)
//		{
//			Password3=0;
//		}
//		else if(value>=1.50 && value<=2.50)
//		{
//			Password3=1;
//		}
//		else
//		{
//			Password3=2;
//		}
//	}	
//		
//}


void Led_Control(int pin,int state)
{
	if(pin>8 || pin<1)
	return;//led��Ų��Ϸ�
	if(state==1)
	{
		HAL_GPIO_WritePin(GPIOD,GPIO_PIN_2,1);
		HAL_GPIO_WritePin(GPIOC,GPIO_PIN_All,1);
		HAL_GPIO_WritePin(GPIOC,GPIO_PIN_7<<pin,0);
		HAL_GPIO_WritePin(GPIOD,GPIO_PIN_2,0);
	}
	else
	{
		HAL_GPIO_WritePin(GPIOD,GPIO_PIN_2,1);
		HAL_GPIO_WritePin(GPIOC,GPIO_PIN_All,1);
		HAL_GPIO_WritePin(GPIOC,GPIO_PIN_7<<pin,1);
		HAL_GPIO_WritePin(GPIOD,GPIO_PIN_2,0);
	}
	
}
