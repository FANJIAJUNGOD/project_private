#ifndef __SHOW_H_
#define __SHOW_H_

void page_show();
void led_control(uint8_t pin,uint8_t state);

#endif
