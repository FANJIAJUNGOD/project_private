#ifndef __KEY_H_
#define __KEY_H_

void Key_Scan(void);

#endif