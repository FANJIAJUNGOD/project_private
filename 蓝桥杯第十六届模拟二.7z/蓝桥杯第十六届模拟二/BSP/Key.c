#include "main.h"
#include "tim.h"
#include "Show.h"
uint8_t key1_state=0;
uint8_t key2_state=0;
uint8_t key3_state=0;
uint8_t key4_state=0;

uint8_t key1_stated=0;
uint8_t key2_stated=0;
uint8_t key3_stated=0;
uint8_t key4_stated=0;

int page_value=0;
int mode=0;
int F1_mode=0;
int F2_mode=0;

uint16_t F1_PARA=1000;


void Key_Scan(void)
{
	key1_state=HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_0);
	key2_state=HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_1);
	key3_state=HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_2);
	key4_state=HAL_GPIO_ReadPin(GPIOA,GPIO_PIN_0);
	
	if(key1_state==0 && key1_stated==1)//�л�����
	{
		HAL_GPIO_WritePin(GPIOD,GPIO_PIN_2,1);
		HAL_GPIO_WritePin(GPIOC,GPIO_PIN_All,1);
		HAL_GPIO_WritePin(GPIOC,GPIO_PIN_8,0);
		HAL_GPIO_WritePin(GPIOD,GPIO_PIN_2,0);
		
		page_value++;
		page_value%=2;//����ҳ
		
	}
	if(key2_state==0 && key2_stated==1)//�л�ģʽ
	{
		mode++;
		mode%=2;
	
	}
	if(key3_state==0 && key3_stated==1)//����F1������
	{
		if(page_value==0)//���ݽ���
		{
			if(mode==0)//key
			{
				if(F1_mode==0)
				{
					HAL_TIM_IC_Start_IT(&htim2,TIM_CHANNEL_1);
					F1_mode=1;
				}							
				else
				{
					HAL_TIM_IC_Stop_IT(&htim2,TIM_CHANNEL_1);
					F1_mode=0;
				}
				//led_control(8,1);
			}	
		}
		else//��������
		{
			F1_PARA+=1000;
			if(F1_PARA>10000)
			{
				F1_PARA=1000;
			}
			
		}
	}
	if(key4_state==0 && key4_stated==1)//����F2������
	{
		if(page_value==0)//���ݽ���
		{
			if(mode==0)//key
			{
				if(F2_mode==0)
				{
					HAL_TIM_IC_Start_IT(&htim3,TIM_CHANNEL_1);
					F2_mode=1;
				}							
				else
				{
					HAL_TIM_IC_Stop_IT(&htim3,TIM_CHANNEL_1);
					F2_mode=0;
				}
				//led_control(8,1);
			}
		}
		else//��������
		{
			F1_PARA-=1000;
			if(F1_PARA<1000)
			{
				F1_PARA=10000;
			}		
		}
	
	}
	
	key1_stated=key1_state;
	key2_stated=key2_state;
	key3_stated=key3_state;
	key4_stated=key4_state;
	
	
}