#include "main.h"
#include "stdio.h"
#include "tim.h"
#include "usart.h"

extern int page_value;
extern int mode;
extern uint16_t F1_PARA;
extern uint8_t mode1;

uint16_t fre ,capture,fre1 ,capture1;
int led3_mode=0;

char buf[32]={0};

void led_control(uint8_t pin,uint8_t state);

void DATA_show()
{
	LCD_DisplayStringLine(Line1, (uint8_t *)"         DATA           ");
	sprintf(buf,"       F1=%d              ",fre);
	LCD_DisplayStringLine(Line3, (uint8_t *)buf);
	sprintf(buf,"       F2=%d              ",fre1);
	LCD_DisplayStringLine(Line4, (uint8_t *)buf);
	if(mode==0)
	{
		LCD_DisplayStringLine(Line5, (uint8_t *)"       MODE=KEY            ");
	}
	else
	{
		LCD_DisplayStringLine(Line5, (uint8_t *)"       MODE=USART            ");			
	}
	
}

void PARE_show()
{
	LCD_DisplayStringLine(Line1, (uint8_t *)"         PARA           ");
	sprintf(buf,"        PF=%d             ",F1_PARA);
	LCD_DisplayStringLine(Line3, (uint8_t *)buf);
	LCD_DisplayStringLine(Line4, (uint8_t *)"                        ");
	LCD_DisplayStringLine(Line5, (uint8_t *)"                        ");
	
}

void page_show()
{
	if(page_value==0)
	{
		DATA_show();	
		if(mode==0)
		{
			if(fre<F1_PARA && fre1<F1_PARA)
			{
				led3_mode=1;
				led_control(3,mode1);
			}
			else
			{
			led3_mode=0;	
			led_control(1,1);	
			}
		}
		else
		{
			led_control(8,1);
		}
	}
				
	else
	{
		PARE_show();
		led_control(2,1);
	}
	
}


void led_control(uint8_t pin,uint8_t state)
{
	if(pin>8 || pin<1) return;
	if(state==1)
	{
		HAL_GPIO_WritePin(GPIOD,GPIO_PIN_2,1);
		HAL_GPIO_WritePin(GPIOC,GPIO_PIN_All,1);
		HAL_GPIO_WritePin(GPIOC,GPIO_PIN_7<<pin,0);
		HAL_GPIO_WritePin(GPIOD,GPIO_PIN_2,0);
	}
	else
	{
		HAL_GPIO_WritePin(GPIOD,GPIO_PIN_2,1);
		HAL_GPIO_WritePin(GPIOC,GPIO_PIN_All,1);
		HAL_GPIO_WritePin(GPIOC,GPIO_PIN_7<<pin,1);
		HAL_GPIO_WritePin(GPIOD,GPIO_PIN_2,0);
	}
	

}
	

void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim)
{
	if(htim->Instance== TIM2)
	{
		capture = HAL_TIM_ReadCapturedValue(&htim2, TIM_CHANNEL_1) + 1;
		fre = 1000000 / capture;
		__HAL_TIM_SetCounter(&htim2,0);//�������㣬������һ�μ���
	}
	if(htim->Instance== TIM3)
	{
		capture1 = HAL_TIM_ReadCapturedValue(&htim3, TIM_CHANNEL_1) + 1;
		fre1 = 1000000 / capture1;
		__HAL_TIM_SetCounter(&htim3,0);//�������㣬������һ�μ���
	}
		
}

